class PuzzleSolver:

    def __init__(self, strategy):

        self.strategy = strategy

    def printPerformance(self):

        print(f'{self.strategy} - Expanded nodes: {self.strategy.numNodes}')

    def printSolution(self):

        print('Solution:')

        for s in self.strategy.solution:
            print(s)

    def run(self):

        if not self.strategy.start.isSolvable():

            raise RuntimeError('This puzzle is not solvable.')

        self.strategy.solvePuzzle()